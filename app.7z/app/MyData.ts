export class MyData{
    

private _numRequest : string;
public get numRequest() : string {
    return this._numRequest;
}
public set numRequest(v : string) {
    this._numRequest = v;
}

private _theNum : string;
public get theNum() : string {
    return this._theNum;
}
public set theNum(v : string) {
    this._theNum = v;
}

    
}