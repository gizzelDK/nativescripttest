import { EventData, Label, NavigatedData, Page } from '@nativescript/core'
import { MainViewModel } from './main-view-model'
import { MyData } from './MyData'

var page: Page
var vm: MainViewModel
var myData: MyData

export function navigatingTo(args: NavigatedData) {
  page = <Page>args.object
  if (!args.isBackNavigation) {
    vm = new MainViewModel()
    page.bindingContext = vm
  }else{
    // myData = page.navigationContext.data
    // console.log(myData.numRequest)
    console.log(myData)
    if (vm.md?.numRequest === 'One') {
      vm.numOne = parseInt(vm.md.theNum)
    }
    if (vm.md?.numRequest === 'Two') {
      vm.numTwo = parseInt(vm.md.theNum)
    }
  }

}
